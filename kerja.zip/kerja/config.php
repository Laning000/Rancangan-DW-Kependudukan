<?php
  $host="localhost";
  $user="root";
  $password="";
  $database="db_dw_kependudukan";
  $Connect = mysqli_connect($host,$user,$password,$database);
?>